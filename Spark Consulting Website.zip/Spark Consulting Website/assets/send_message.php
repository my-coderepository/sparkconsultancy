<?php

// Twilio credentials
$twilioAccountSid = 'ACa37cb84a58bc17093587f0f078bfdd68';
$twilioAuthToken = '86f1f5e303f2a15d4430983271da88e9';
$twilioPhoneNumber = 'whatsapp:+14155238886'; // Your Twilio sandbox number

// Recipient's phone number (in E.164 format, e.g., +14155550123)
$recipientPhoneNumber = 'whatsapp:+919063300200'; // Your WhatsApp number

// Message content
$messageBody = "This is a test message from Twilio Sandbox";

// Initialize Twilio client
$client = new Twilio\Rest\Client($twilioAccountSid, $twilioAuthToken);

try {
    // Send message
    $client->messages->create(
        $recipientPhoneNumber,
        [
            'from' => $twilioPhoneNumber,
            'body' => $messageBody
        ]
    );

    echo 'Message sent successfully.';
} catch (Exception $e) {
    echo 'Error: ' . $e->getMessage();
}
?>
